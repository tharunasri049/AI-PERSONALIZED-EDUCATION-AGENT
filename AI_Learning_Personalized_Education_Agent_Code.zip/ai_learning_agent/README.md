# AI Learning & Personalized Education Agent

A demo-ready full-stack prototype based on the project PPT: personalized student profile, quick assessment, AI tutor, quiz generation, adaptive next-topic recommendation, progress tracking, multilingual responses, and RAG-ready architecture.

## Stack
- Backend: Python + FastAPI + SQLite
- Frontend: React (Vite)
- AI: optional OpenAI-compatible API; demo fallback works without an API key
- RAG: local syllabus knowledge base with keyword retrieval (easy to replace with Chroma later)

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Optional `.env`:
```env
LLM_API_KEY=your_key
LLM_BASE_URL=https://api.openai.com/v1
LLM_MODEL=gpt-4o-mini
```

## Run frontend
```bash
cd frontend
npm install
npm run dev
```
Open the URL shown by Vite (usually http://localhost:5173).

## Demo flow for supervisor
1. Create/load student profile.
2. Take the quick assessment.
3. Ask the AI tutor a syllabus question.
4. Generate a quiz.
5. Submit answers; backend records the score.
6. Dashboard recommends the next topic from performance.
