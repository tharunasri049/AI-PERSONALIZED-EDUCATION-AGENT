import os, re, sqlite3, json
from typing import Optional, List
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

load_dotenv()
DB = "learning_agent.db"
app = FastAPI(title="AI Learning & Personalized Education Agent")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

KNOWLEDGE = [
 {"topic":"Python Basics","text":"Python variables store values. Common types include int, float, str, list and bool. input() reads text and int() converts numeric text to an integer."},
 {"topic":"Data Structures","text":"Arrays/lists store ordered items. Stacks follow LIFO. Queues follow FIFO. Hash tables provide fast average-case key lookup."},
 {"topic":"DBMS","text":"A database stores structured data. Primary keys uniquely identify rows. Normalization reduces redundancy. SQL is used to query relational databases."},
 {"topic":"Computer Networks","text":"An IP address identifies a host/interface. TCP provides reliable, connection-oriented delivery. HTTP is an application-layer protocol used for web communication."},
 {"topic":"Operating Systems","text":"A process is a program in execution. CPU scheduling selects processes for execution. Virtual memory uses secondary storage to extend the apparent memory space."},
]

class Profile(BaseModel):
    name: str
    subject: str = "Computer Science"
    goal: str = "GATE preparation"
    language: str = "English"
    level: str = "Beginner"

class Question(BaseModel):
    topic: str
    question: str
    answer: str
    difficulty: str = "Easy"

class Assessment(BaseModel):
    student_id: int
    answers: List[int]

class Ask(BaseModel):
    student_id: int
    question: str

class QuizRequest(BaseModel):
    student_id: int
    topic: str
    count: int = 5


def db():
    con=sqlite3.connect(DB)
    con.row_factory=sqlite3.Row
    return con

def init_db():
    con=db(); c=con.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,subject TEXT,goal TEXT,language TEXT,level TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,topic TEXT,score REAL,total INTEGER)")
    c.execute("CREATE TABLE IF NOT EXISTS chats(id INTEGER PRIMARY KEY AUTOINCREMENT,student_id INTEGER,question TEXT,answer TEXT)")
    con.commit(); con.close()
init_db()

def retrieve(q:str):
    words=set(re.findall(r"[a-zA-Z]{3,}", q.lower()))
    ranked=[]
    for item in KNOWLEDGE:
        text=(item['topic']+' '+item['text']).lower()
        score=sum(1 for w in words if w in text)
        ranked.append((score,item))
    return [x[1] for x in sorted(ranked,key=lambda x:x[0],reverse=True)[:2] if x[0]>0]

def fallback_answer(q, context, language):
    if context:
        body=" ".join(x['text'] for x in context)
        return f"Here is a simple explanation: {body}\\n\\nExample: connect the concept to a small real-world problem and practise it with one question."
    return "I could not find this topic in the current syllabus knowledge base. Please ask a question about Python, Data Structures, DBMS, Computer Networks, or Operating Systems."

async def llm_answer(q, context, language):
    key=os.getenv('LLM_API_KEY'); base=os.getenv('LLM_BASE_URL','https://api.openai.com/v1').rstrip('/'); model=os.getenv('LLM_MODEL','gpt-4o-mini')
    if not key: return fallback_answer(q,context,language)
    prompt=f"You are a patient educational tutor. Answer in {language}. Use only the supplied syllabus context when possible. Explain simply, step-by-step, with one example. Context: {json.dumps(context)} Question: {q}"
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            r=await client.post(base+'/chat/completions',headers={'Authorization':f'Bearer {key}'},json={'model':model,'messages':[{'role':'system','content':'You are an educational tutor.'},{'role':'user','content':prompt}], 'temperature':0.2})
            r.raise_for_status(); return r.json()['choices'][0]['message']['content']
    except Exception:
        return fallback_answer(q,context,language)

@app.get('/api/health')
def health(): return {'status':'ok','service':'AI Learning Agent'}

@app.post('/api/students')
def create_student(p:Profile):
    con=db(); cur=con.execute('INSERT INTO students(name,subject,goal,language,level) VALUES(?,?,?,?,?)',(p.name,p.subject,p.goal,p.language,p.level)); con.commit(); sid=cur.lastrowid; con.close(); return {'id':sid,**p.model_dump()}

@app.get('/api/students/{sid}')
def get_student(sid:int):
    con=db(); row=con.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone(); con.close()
    if not row: raise HTTPException(404,'Student not found')
    return dict(row)

@app.get('/api/topics')
def topics(): return {'topics':[x['topic'] for x in KNOWLEDGE]}

ASSESSMENT=[
 {'q':'Which type is returned by input() in Python?','options':['int','str','float','bool'],'answer':1,'topic':'Python Basics'},
 {'q':'Which data structure follows LIFO?','options':['Queue','Stack','Graph','Tree'],'answer':1,'topic':'Data Structures'},
 {'q':'What uniquely identifies a row in a relational table?','options':['Foreign key','Primary key','Index only','View'],'answer':1,'topic':'DBMS'},
 {'q':'Which protocol is reliable and connection-oriented?','options':['UDP','TCP','IP','ARP'],'answer':1,'topic':'Computer Networks'},
 {'q':'A program in execution is called what?','options':['Thread only','Process','Compiler','Packet'],'answer':1,'topic':'Operating Systems'},
]
@app.get('/api/assessment')
def assessment(): return {'questions':ASSESSMENT}

@app.post('/api/assessment/submit')
def submit_assessment(a:Assessment):
    if len(a.answers)!=len(ASSESSMENT): raise HTTPException(400,'Submit all answers')
    score=sum(x['answer']==ans for x,ans in zip(ASSESSMENT,a.answers)); pct=score/len(ASSESSMENT)*100
    topic_scores={}
    for x,ans in zip(ASSESSMENT,a.answers):
        topic_scores[x['topic']]={'correct': x['answer']==ans}
    con=db();
    for topic,v in topic_scores.items(): con.execute('INSERT INTO attempts(student_id,topic,score,total) VALUES(?,?,?,?)',(a.student_id,topic,100 if v['correct'] else 0,1))
    con.commit(); con.close()
    return {'score':score,'total':len(ASSESSMENT),'percentage':pct,'topic_scores':topic_scores}

@app.post('/api/ask')
async def ask(a:Ask):
    con=db(); student=con.execute('SELECT * FROM students WHERE id=?',(a.student_id,)).fetchone();
    if not student: raise HTTPException(404,'Student not found')
    context=retrieve(a.question); answer=await llm_answer(a.question,context,student['language'])
    con.execute('INSERT INTO chats(student_id,question,answer) VALUES(?,?,?)',(a.student_id,a.question,answer)); con.commit(); con.close()
    return {'answer':answer,'sources':[x['topic'] for x in context]}

QUIZZES={
 'Python Basics':[
  ['Which function reads keyboard input?',['print()','input()','read()','scan()'],1,'input() reads user input.'],
  ['What does int("5") produce?',['String 5','Integer 5','Float 5.0','Boolean'],1,'int converts numeric text to an integer.'],
  ['Which is mutable?',['tuple','list','str','int'],1,'Lists can be changed after creation.'],
  ['Which symbol starts a comment?',['//','#','/*','--'],1,'Python comments start with #.'],
  ['Which keyword defines a function?',['func','define','def','function'],2,'def defines a function.']
 ],
 'Data Structures':[
  ['LIFO is used by?',['Queue','Stack','Heap only','Graph'],1,'Stack uses Last-In-First-Out.'],
  ['FIFO is used by?',['Queue','Stack','Tree','Set'],0,'Queue uses First-In-First-Out.'],
  ['Key-value lookup is typical of?',['Hash table','Stack','Queue','Array only'],0,'Hash tables map keys to values.'],
  ['A tree is usually?',['Linear only','Hierarchical','Random text','Protocol'],1,'Trees represent hierarchical relationships.'],
  ['Which is ordered?',['List','Set only','Hash table only','None'],0,'Python lists preserve order.']
 ]
}
@app.post('/api/quiz')
def quiz(r:QuizRequest):
    data=QUIZZES.get(r.topic,QUIZZES['Python Basics'])[:max(1,min(r.count,5))]
    return {'topic':r.topic,'questions':[{'id':i,'question':q,'options':opts,'answer':ans,'explanation':exp} for i,(q,opts,ans,exp) in enumerate(data)]}

class QuizSubmit(BaseModel):
    student_id:int; topic:str; answers:List[int]; correct_answers:List[int]
@app.post('/api/quiz/submit')
def quiz_submit(s:QuizSubmit):
    total=len(s.correct_answers); score=sum(a==b for a,b in zip(s.answers,s.correct_answers)); pct=score/total*100 if total else 0
    con=db(); con.execute('INSERT INTO attempts(student_id,topic,score,total) VALUES(?,?,?,?)',(s.student_id,s.topic,pct,total)); con.commit(); con.close()
    return {'score':score,'total':total,'percentage':pct,'recommendation': 'Revise this topic and try another quiz.' if pct<70 else 'Good job. Move to the next difficulty level.'}

@app.get('/api/dashboard/{sid}')
def dashboard(sid:int):
    con=db(); rows=con.execute('SELECT topic,AVG(score) avg_score FROM attempts WHERE student_id=? GROUP BY topic',(sid,)).fetchall(); con.close()
    scores=[dict(r) for r in rows]; weak=sorted(scores,key=lambda x:x['avg_score'])[:2]
    return {'scores':scores,'weak_topics':[x['topic'] for x in weak], 'next_action': f"Revise {weak[0]['topic']}" if weak else 'Take the quick assessment'}
